@php
    /** @var $user \App\User */
@endphp
@component('mail::message')
# A new User Has Registered

### Details:
* Name: {{ $user->full_name() }}
* Email: {{ $user->email }}
* Phone: {{ $user->phone }} @if ($user->phone_ext) {{$user->phone_ext}} @endif
* Website: {{ $user->website }}
* User Type: {{ $user->user_type === 'realtor' ? 'realtor' : 'lender' }}
* City: {{ $user->city }}
* State: {{ $user->state }}
* Postal Code: {{ $user->zip }}
* Register Date: {{ $user->register_ts->format('Y-m-d H:i:s') }}
* Company: {{ $user->firm_name }}


Thanks,<br>
{{ config('app.name') }}
@endcomponent