@component('mail::message')
# {{ $title }}
Number of users registered: {{$total_users}}

The report is attached.

@endcomponent