<div class="page-header">
    {{ $page_header }}
</div>

{{ $slot }}