<div class="row">
    <div class="col-sm-3">
        {{ $sidebar }}
    </div>
    <div class="col-sm-9">
        {{ $slot }}
    </div>
</div>