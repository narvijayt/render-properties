<div class="sponsors">
    <h4>Sponsors</h4>
    <img src="public/img/sponsor_1.jpg" class="img-responsive">
    <img src="public/img/sponsor_2.jpg" class="img-responsive">
</div>