<?php /** @var \App\Match $match */ ?>
@php
    $oppUser = $match->getOppositeParty($user);
@endphp
<li>
    <div class="match-result">
        <div class="row">

            <div class="col-xs-6 match-result__content">
                <div class="match-result__image">
                    <img src="{{ $oppUser->avatarUrl() }}" />
                </div>
                <div class="match-result__name">
                    {{ $oppUser->full_name() }}
                  
                </div>
                <span>
                    <a href="{{ route('pub.user.show', $oppUser->user_id) }}">View Profile</a>
                </span>
            </div>


            <div class="col-xs-6 match-result__action-container">
                @if ($match->isAccepted())
                     @php
                        echo '<button class="btn btn-warning btn-sm" onclick="confirmMatch(\''.$match->match_id.'\' , \'remove\');">Remove Match</button>';
                    @endphp
                @endif
                @if (!$match->isAccepted() && !$match->isDeleted())
                     @php
                        echo '<button class="btn btn-warning btn-sm" onclick="confirmMatch(\''.$match->match_id.'\' , \'reject_match\');">Reject Match</button>';
                    @endphp
                @endif
               {{-- @if (!$match->isAcceptedBy($user) && $user->availableMatchCount() > 0) --}}
                @if (!$match->isAcceptedBy($user))
                    @php
                        echo '<button class="btn btn-warning btn-sm" onclick="confirmMatch(\''.$match->match_id.'\' , \'accept\');">Confirm</button>';
                    @endphp
                @endif

                {{--@if (!$match->isAcceptedBy($user) && $user->availableMatchCount() <= 0 && $user->user_type === \App\Enums\UserAccountType::BROKER)--}}
                    {{--<a href="{{ route('pub.profile.payment.purchase-matches-show') }}"--}}
                       {{--class="btn btn-warning btn-sm"--}}
                       {{-->Purchase Additional Matches</a>--}}
                {{--@endif--}}

                {{--@can('requestMatch', $oppUser)--}}
                    {{--<form--}}
                        {{--class="match-result__form-action"--}}
                        {{--action="{{ route('pub.matches.request-match', $oppUser) }}"--}}
                        {{--id="request-match-{{ $oppUser->user_id }}"--}}
                        {{--method="POST">--}}
                        {{--{{ csrf_field() }}--}}
                        {{--<button--}}
                            {{--class="btn btn-warning btn-sm"--}}
                            {{--type="button"--}}
                            {{--data-toggle="modal"--}}
                            {{--data-confirm-submit="#request-match-{{ $oppUser->user_id }}"--}}
                            {{--data-confirm-message="Are you sure you wish to request a match with {{ $oppUser->full_name() }}"--}}
                            {{--data-target="#confirm-submit-modal"--}}
                        {{-->Request Match</button>--}}
                    {{--</form>--}}
                {{--@endcan--}}

                @can('renewMatch', $oppUser)
                    @php
                        echo '<button class="btn btn-warning btn-sm" onclick="confirmMatch(\''.$oppUser->user_id.'\' , \'renew\');">Renew Match</button>';
                    @endphp
                    <div>Renewable until {{ $match->deleted_at->addMonth(1)->format("F m, Y") }}</div>
                @endcan
                @can('acceptRenewMatch', $oppUser)
                   @php
                        echo '<button class="btn btn-warning btn-sm" onclick="confirmMatch(\''.$match->match_id.'\' , \'confirm_renew\');">Accept Match Renewal</button>';
                    @endphp
                @endcan

                @if($match->renewal && $match->renewal->isAcceptedBy($user) && !$match->renewal->isAcceptedBy($oppUser))
                    Pending Approval
                @endif

                @if($match->renewal)
                    @can('rejectRenewMatch', $oppUser)
                        @php
                            echo '<button class="btn btn-warning btn-sm" onclick="confirmMatch(\''.$match->match_id.'\' , \'reject_renew_match\');">Reject</button>';
                        @endphp
                    @endcan
                @endif
            </div>

        </div>
    </div>

</li>

<div class="modal" tabindex="-1" role="dialog" id="confirm-submit-modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="cls-cross"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Confirm</h4>
            </div>
            <div class="modal-body">
                <p id="confirm-submit-modal-message">Are you sure?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" aria-label="Close" id="cls">Close</button>
                <button type="button" class="btn btn-primary" id="confirm-submit-modal-accept" aria-label="Yes">Yes</button>
				<div id="loading-imgs" style="display: none; position: absolute; z-index: 9; top: 60%; left: 50%; transform: translate(-50%, -50%);">
					<img src="{{asset('public/img/profile-loader.gif')}}" />
				</div>
            </div>
        </div>
    </div>
</div>
@push('scripts-footer')
    <script>
        function confirmMatch(id, type) {
            $('#confirm-submit-modal').show();
            if(type==='remove') {
                $('#confirm-submit-modal-message').text('Are you sure want to remove this match?')
            } else if(type==='renew') {
                $('#confirm-submit-modal-message').text('Are you sure you wish to renew the match with this user?')
            } else if(type==='confirm_renew') {
                $('#confirm-submit-modal-message').text('Are you sure you wish to accept the match renewal with this user?')
            } else if(type==='reject_match') {
                $('#confirm-submit-modal-message').text('Are you sure you wish to reject the match with this user?')
            } else if(type==='reject_renew_match') {
                $('#confirm-submit-modal-message').text('Are you sure you wish to reject the match renewal with this user?')
            }

            $("#confirm-submit-modal-accept").on('click', function() {
                var app_url = 'https://www.render.properties/matches';
                if(type==='accept') {
                    var url = app_url+'/'+id+'/confirm-match';
                } else if(type==='remove') {
                    var url = app_url+'/'+id+'/remove-match';
                } else if(type==='renew') {
                    var url = app_url+'/'+id+'/request-renew-match';
                } else if(type==='confirm_renew') {
                    var url = app_url+'/'+id+'/confirm-renew-match';
                } else if(type==='reject_match') {
                    var url = app_url+'/'+id+'/reject-match';
                } else if(type==='reject_renew_match') {
                    var url = app_url+'/'+id+'/reject-renew-match';
                }
                $.ajax({
                    type: 'POST',
                    url: url,
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
					beforeSend: function() {
						$("#loading-imgs").show();
					},	
                    success: function (data) {
						$("#loading-imgs").hide();
                        $('#confirm-submit-modal').hide();
                        window.location.reload();
                    }
                });
            })
        }

        $(document).on('click', '#cls',function(){
            $('#confirm-submit-modal').hide();
        });

        $(document).on('click', '#cls-cross',function(){
            $('#confirm-submit-modal').hide();
        });
    </script>
@endpush