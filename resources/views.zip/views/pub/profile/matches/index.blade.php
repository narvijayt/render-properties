@extends('pub.profile.layouts.profile')

@section('title', 'Manage Matches')

@section('page_content')

    <div>
        {{--You are currently using {{ $usedMatchesCount }} of {{ $purchasedMatchesCount }} available matches.--}}
        {{--@can('purchase-additional-matches', \App\User::class)--}}
            {{--<a href="{{ route('pub.profile.payment.purchase-matches-show') }}" class="btn btn-warning btn-sm pull-right">Purchase More</a>--}}
        {{--@endcan--}}
    </div>
    <div class="row">
        <div class="col-md-12">

            @if ($activeMatches->count() !== 0)
                <h3>Existing Matches</h3>
                <?php /** @var \App\Match $match */ ?>
                <ul class="list-unstyled">
                @foreach($activeMatches as $match)
                    @include('pub.profile.partials.matches.result', [
                        'user' => $user,
                        'match' => $match,
                    ])
                @endforeach
                </ul>
            @endif

            @if($pendingMatches !== 0)
                <h3>Pending Matches</h3>
                <ul class="list-unstyled">
                    @foreach($pendingMatches as $match)
                        @include('pub.profile.partials.matches.result', [
                            'user' => $user,
                            'match' => $match
                        ])
                    @endforeach
                </ul>
            @endif

            @if($renewableMatches !== 0)
                <h3>Renewable Matches</h3>
                <ul class="list-unstyled">
                    @foreach($renewableMatches as $match)
                        @include('pub.profile.partials.matches.result', [
                            'user' => $user,
                            'match' => $match
                        ])
                    @endforeach
                </ul>
            @endif

        </div>
    </div>

@endsection

