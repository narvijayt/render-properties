@extends('pub.profile.layouts.profile')

@section('title')Dashboard@stop

@section('page_content')
    <h3 class="margin-top-none">
        Dashboard stuff!
    </h3>
@endsection