@extends('pub.profile.layouts.profile')

@section('title')
    No Subscription
@endsection

@section('page_content')
<div class="panel panel-default">
    <div class="panel-heading">
        Subscription Details
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        Invoices
    </div>
</div>
@endsection