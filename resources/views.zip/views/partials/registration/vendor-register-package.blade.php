	  <div class="box-title-box text-center">
	    <h1 class="box-title line-center family-mont">Vendor Advertising Packages</h1>
         <p> Reach Top Performing Lender And Real Estate Agents Online</p>
	 </div>


<div class="package-header">
        <div class="">
		
            <div class="text-center">
                <div class="pricing-table  text-center starter">
                <div class="head"><h3 class="period">PICK A CITY</h3></div>
				
				  <div class="middle">
                                    <h1 class="price"><span>$</span>99 <u>MO</u></h1>
                                    <p class="small-price">For One City</p>
                                   <h1 class="price"><span>$</span>79 <u>MO</u></h1>
                                    <p class="small-price">EACH ADDITIONAL*</p>									
                                  </div>
                                 
               </div>
                   </div>
				  <div class="text-center">
                <div class="pricing-table  text-center starter">
                <div class="head"><h3 class="period">PICK A STATE</h3></div>
				
				  <div class="middle">
                                    <h1 class="price"><span>$</span>799 <u>MO</u></h1>
                                    <p class="small-price">FOR ONE STATE*</p>
                                   <h1 class="price"><span>$</span>599 <u>MO</u></h1>
                                    <p class="small-price">EACH ADDITIONAL*</p>									
                                  </div>

                 </div>
                  </div>
				   <div class="text-center">
                <div class="pricing-table  text-center starter">
                <div class="head"><h3 class="period">UNITED STATES</h3></div>
				
				  <div class="middle">
                                    <h1 class="price"><span>$</span>8995 <u>MO</u></h1>
                                    <p class="small-price">FOR ONE MONTH</p>
                                    <h2 class="text-white highlighted-text">OWN THE U.S. IN YOUR INDUSTRY!!!</h2>									
                                  </div>
    </div>
                  </div>
		</div>
    </div>