<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
    <rect x="3" y="15.145" fill="#FF0000" width="26" height="16.855"/>
    <polygon fill="#FF0000" points="0,15.887 16,0 32,15.887 "/>
    <polygon fill="#FFFFFF" points="23.107,28.77 16.021,25.063 8.952,28.801 10.287,20.915 4.548,15.346 12.459,14.179 15.983,7 19.537,14.164 27.451,15.297 21.738,20.891 "/>
</svg>