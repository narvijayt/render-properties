<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
    <rect x="3" y="15.145" fill="#AFAFAF" width="26" height="16.855"/>
    <polygon fill="#AFAFAF" points="0,15.887 16,0 32,15.887 "/>
</svg>