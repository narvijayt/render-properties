<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="3" y1="23.5723" x2="29" y2="23.5723">
    <stop  offset="0" style="stop-color:#FF0000"/>
    <stop  offset="0.5" style="stop-color:#F51717"/>
    <stop  offset="0.5" style="stop-color:#AFAFAF"/>
</linearGradient>
    <rect x="3" y="15.145" fill="url(#SVGID_1_)" width="26" height="16.855"/>
    <linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="7.9434" x2="32" y2="7.9434">
        <stop  offset="0" style="stop-color:#FF0000"/>
        <stop  offset="0.5" style="stop-color:#F51717"/>
        <stop  offset="0.5" style="stop-color:#AFAFAF"/>
    </linearGradient>
    <polygon fill="url(#SVGID_2_)" points="0,15.887 16,0 32,15.887 "/>
    <g>
        <polygon fill="none" points="8.792,28.801 10.171,20.915 4.237,15.346 12.418,14.179 16.009,7.105 16.009,5 0,5 0,30 16.009,30
		16.009,25.11 	"/>
        <polygon fill="#FFFFFF" points="4.237,15.346 10.171,20.915 8.792,28.801 16.009,25.11 16.009,7.105 12.418,14.179 	"/>
    </g>
</svg>