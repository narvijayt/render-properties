<script src="{{asset('public/js/admin/jquery/jquery.min.js')}}"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/js/bootstrapValidator.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script src="{{asset('public/js/admin/bootstrap/bootstrap.min.js')}}"></script>
<script src="{{asset('public/js/admin/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('public/js/admin/datatables/dataTables.bootstrap.min.js')}}"></script>
<script src="{{asset('public/js/admin/admin.min.js')}}"></script>
<script src="{{asset('public/js/admin/jquery-sparkline/jquery.sparkline.min.js')}}"></script>
<script src="{{asset('public/js/admin/jquery-slimscroll/jquery.slimscroll.min.js')}}"></script>
<script src="{{asset('public/js/admin/tinymce/tinymce.min.js')}}"></script>
<script src="{{asset('public/js/admin/ckeditor/ckeditor.js')}}"></script>
<script src="{{asset('public/js/admin/demo.js')}}"></script>